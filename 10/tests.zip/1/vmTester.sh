echo '====YGameMain.vm====' 
diff -w YGameMain.vm YGameMainA.vm
echo '====Array.vm===='
diff -w ArrayA.vm Array.vm
echo '====CaveShooterMain.vm====' 
diff -w CaveShooterMain.vm CaveShooterMainA.vm
echo '====PlatformsGenerator.vm====' 
diff -w PlatformsGenerator.vm PlatformsGeneratorA.vm
echo '====SlowAppender.vm==== '
diff -w SlowAppender.vm SlowAppenderA.vm
echo '====Random.vm===='
diff -w Random.vm RandomA.vm
echo '====Ball.vm====' 
diff -w Ball.vm BallA.vm
echo '====Cannon.vm===='
diff -w Cannon.vm CannonA.vm
echo '====CaveShooterBall.vm====' 
diff -w CaveShooterBall.vm CaveShooterBallA.vm
echo '====Fly.vm====' 
diff -w Fly.vm FlyA.vm
echo '====Frog.vm====' 
diff -w Frog.vm FrogA.vm
echo '====Fruit.vm====' 
diff -w Fruit.vm FruitA.vm
echo '====Keyboard.vm====' 
diff -w Keyboard.vm KeyboardA.vm
echo '====Log.vm====' 
diff -w Log.vm LogA.vm
echo '====Main.vm====' 
diff -w Main.vm MainA.vm
echo '====MainFruit.vm====' 
diff -w MainFruit.vm MainFruitA.vm
echo '====Math.vm====' 
diff -w Math.vm MathA.vm
echo '====Memory.vm===='
diff -w Memory.vm MemoryA.vm
echo '====Platform.vm==== '
diff -w Platform.vm PlatformA.vm
echo '====PlatformsList.vm====' 
diff -w PlatformsList.vm PlatformsListA.vm
echo '====Problem.vm====' 
diff -w Problem.vm ProblemA.vm
echo '====RandomNumbersGenerator.vm==== '
diff -w RandomNumbersGenerator.vm RandomNumbersGeneratorA.vm
echo '====RapidRollGame.vm==== '
diff -w RapidRollGame.vm RapidRollGameA.vm
echo '====Screen.vm==== '
diff -w Screen.vm ScreenA.vm
echo '====Square.vm==== '
diff -w Square.vm SquareA.vm
echo '====SquareGame.vm====' 
diff -w SquareGame.vm SquareGameA.vm
echo '====Sys.vm====' 
diff -w Sys.vm SysA.vm
echo '====try1.vm====' 
diff -w try1.vm try1A.vm
echo '====Utils.vm====' 
diff -w Utils.vm UtilsA.vm
echo '====YMain.vm====' 
diff -w YMain.vm YMainA.vm
