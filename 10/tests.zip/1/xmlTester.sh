echo '====YGameMain.xml====' 
diff -w YGameMain.xml YGameMainA.xml
echo '====Array.xml===='
diff -w ArrayA.xml Array.xml
echo '====CaveShooterMain.xml====' 
diff -w CaveShooterMain.xml CaveShooterMainA.xml
echo '====PlatformsGenerator.xml====' 
diff -w PlatformsGenerator.xml PlatformsGeneratorA.xml
echo '====SlowAppender.xml==== '
diff -w SlowAppender.xml SlowAppenderA.xml
echo '====Random.xml===='
diff -w Random.xml RandomA.xml
echo '====Ball.xml====' 
diff -w Ball.xml BallA.xml
echo '====Cannon.xml===='
diff -w Cannon.xml CannonA.xml
echo '====CaveShooterBall.xml====' 
diff -w CaveShooterBall.xml CaveShooterBallA.xml
echo '====Fly.xml====' 
diff -w Fly.xml FlyA.xml
echo '====Frog.xml====' 
diff -w Frog.xml FrogA.xml
echo '====Fruit.xml====' 
diff -w Fruit.xml FruitA.xml
echo '====Keyboard.xml====' 
diff -w Keyboard.xml KeyboardA.xml
echo '====Log.xml====' 
diff -w Log.xml LogA.xml
echo '====Main.xml====' 
diff -w Main.xml MainA.xml
echo '====MainFruit.xml====' 
diff -w MainFruit.xml MainFruitA.xml
echo '====Math.xml====' 
diff -w Math.xml MathA.xml
echo '====Memory.xml===='
diff -w Memory.xml MemoryA.xml
echo '====Platform.xml==== '
diff -w Platform.xml PlatformA.xml
echo '====PlatformsList.xml====' 
diff -w PlatformsList.xml PlatformsListA.xml
echo '====Problem.xml====' 
diff -w Problem.xml ProblemA.xml
echo '====RandomNumbersGenerator.xml==== '
diff -w RandomNumbersGenerator.xml RandomNumbersGeneratorA.xml
echo '====RapidRollGame.xml==== '
diff -w RapidRollGame.xml RapidRollGameA.xml
echo '====Screen.xml==== '
diff -w Screen.xml ScreenA.xml
echo '====Square.xml==== '
diff -w Square.xml SquareA.xml
echo '====SquareGame.xml====' 
diff -w SquareGame.xml SquareGameA.xml
echo '====Sys.xml====' 
diff -w Sys.xml SysA.xml
echo '====try1.xml====' 
diff -w try1.xml try1A.xml
echo '====Utils.xml====' 
diff -w Utils.xml UtilsA.xml
echo '====YMain.xml====' 
diff -w YMain.xml YMainA.xml
