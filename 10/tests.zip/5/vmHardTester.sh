echo '====FrogGame.vm====' 
diff -w FrogGame.vm FrogGameA.vm
echo '====GameControl.vm====' 
diff -w GameControl.vm GameControlA.vm
echo '====in3.vm====' 
diff -w in3.vm in3A.vm
echo '====simpleCommentTest.vm====' 
diff -w simpleCommentTest.vm simpleCommentTestA.vm
echo '====Surface.vm====' 
diff -w Surface.vm SurfaceA.vm
echo '====try2.vm===='
diff -w try2.vm try2A.vm
